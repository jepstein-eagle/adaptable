


export interface ICustomSort {
    ColumnId: string;
    CustomSortItems: Array<string>
}