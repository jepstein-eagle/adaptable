import {IColumn} from './IAdaptableBlotter';
import {IStrategy} from './IStrategy';

export interface IColumnChooserStrategy extends IStrategy {
}