import {IStrategy} from './IStrategy';

export interface IUserDataManagementStrategy extends IStrategy{
    
}